---
Download Help Link: https://aka.ms/powershell51-help
Help Version: 6.2.0.0
Locale: en-US
Module Guid: 25bd9e34-bff9-4552-a23d-854857b42462
Module Name: Microsoft.PowerShell.Operation.Validation
ms.date: 06/09/2017
schema: 2.0.0
title: Microsoft.PowerShell.Operation.Validation
---
# Microsoft.PowerShell.Operation.Validation Module

## Description

This section has links to the Operation Validation Framework cmdlets.

## Microsoft.PowerShell.Operation.Validation Cmdlets

### [Get-OperationValidation](Get-OperationValidation.md)
Gets Operation Validation Framework tests.

### [Invoke-OperationValidation](Invoke-OperationValidation.md)
Invokes Operation Validation Framework tests.
